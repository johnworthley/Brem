const mHost = "127.0.0.1:8080";

export default mHost;
