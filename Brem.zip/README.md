<p align="center">
  <img width="600" height ="240"  alt="Brem" src = "./assets/Brem1.png">
</p>

# Brem

# Project descruption 
BREM platform is a perspective investment project of the world's
first online portal for real estate transactions (from now on referred
to as the"Portal" or "Platform"), created with the blockchain technology. This portal aims to unite the Developers with a full, world-scale base
of real estate objects (placing objects on the platform), and the real estate agencies and investors (the buyers).

# Dependencies 
[![truffle](https://img.shields.io/badge/truffle-v3.4.11-orange.svg)](https://truffle.readthedocs.io/en/latest/)
[![solidity](https://img.shields.io/badge/solidity-docs-red.svg)](http://solidity.readthedocs.io/en/develop/types.html)

# Smart contracts


# Created by 
<p align="center">
  <img width="240" height ="240" alt="Hashlab" src = "./assets/Hashlab.jpg">
</p>
